
"use client";

import * as React from "react";
import Image from "next/image";
import { useSound } from "@/hooks/use-sound";

/**
 * A highly optimized preloader component that displays a simple, fast-loading animation with the app logo.
 * This version features a spinning gradient border and plays a sound on the first user interaction.
 */
export function Preloader() {
  const { playSound } = useSound();

  React.useEffect(() => {
    const playSoundOnFirstInteraction = () => {
      playSound('preloader');
      // Clean up listeners after the first interaction to avoid playing the sound again
      window.removeEventListener('click', playSoundOnFirstInteraction);
      window.removeEventListener('keydown', playSoundOnFirstInteraction);
      window.removeEventListener('scroll', playSoundOnFirstInteraction);
    };

    // Add listeners for the first user interaction
    window.addEventListener('click', playSoundOnFirstInteraction, { once: true });
    window.addEventListener('keydown', playSoundOnFirstInteraction, { once: true });
    window.addEventListener('scroll', playSoundOnFirstInteraction, { once: true });

    // Cleanup function to remove listeners if the component unmounts
    return () => {
      window.removeEventListener('click', playSoundOnFirstInteraction);
      window.removeEventListener('keydown', playSoundOnFirstInteraction);
      window.removeEventListener('scroll', playSoundOnFirstInteraction);
    };
  }, [playSound]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-background text-foreground">
      <div className="relative flex items-center justify-center">
        {/* Spinning gradient border */}
        <div 
          className="absolute h-32 w-32 animate-spin-slow rounded-full"
          style={{
            background: 'conic-gradient(from 180deg at 50% 50%, hsl(var(--primary)) 0%, transparent 75%)',
          }}
        />
        {/* Inner mask to create the ring effect */}
        <div className="absolute h-28 w-28 rounded-full bg-background" />

        <Image
          src="/images/logo.png"
          alt="Pentecostal Church of the Living God Logo"
          width={96}
          height={96}
          className="relative"
          priority
        />
      </div>
    </div>
  );
}
