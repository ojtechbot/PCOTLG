
"use client"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useState } from "react";
import { verifyOtp } from "@/ai/flows/verify-otp";
import { Loader2, Mail } from "lucide-react";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSeparator,
  InputOTPSlot,
} from "@/components/ui/input-otp"

interface OtpVerificationDialogProps {
  email: string;
  onOpenChange: (open: boolean) => void;
  onVerified: () => void;
}

export function OtpVerificationDialog({ email, onOpenChange, onVerified }: OtpVerificationDialogProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [otp, setOtp] = useState("");

  const handleVerifyOtp = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (otp.length !== 6) return;
    setIsLoading(true);
    
    try {
        const result = await verifyOtp({ email, otp });
        if (result.success) {
            toast({
                title: "Email Verified!",
                description: "Your account is being created.",
            });
            onVerified(); // Signal parent to create user
        } else {
            toast({
                variant: "destructive",
                title: "Verification Failed",
                description: result.message,
            });
        }
    } catch (error) {
        console.error(error);
        toast({
            variant: "destructive",
            title: "An error occurred",
            description: "Failed to verify OTP. Please try again.",
        });
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
          <form onSubmit={handleVerifyOtp}>
            <DialogHeader>
              <DialogTitle className="text-center">Verify Your Email</DialogTitle>
              <DialogDescription className="text-center">
                We've sent a 6-digit code to <span className="font-semibold text-primary">{email}</span>. Please enter it below.
              </DialogDescription>
            </DialogHeader>
            <div className="flex justify-center py-8">
                <InputOTP maxLength={6} value={otp} onChange={(value) => setOtp(value)}>
                    <InputOTPGroup>
                        <InputOTPSlot index={0} />
                        <InputOTPSlot index={1} />
                        <InputOTPSlot index={2} />
                    </InputOTPGroup>
                    <InputOTPSeparator />
                    <InputOTPGroup>
                        <InputOTPSlot index={3} />
                        <InputOTPSlot index={4} />
                        <InputOTPSlot index={5} />
                    </InputOTPGroup>
                </InputOTP>
            </div>
            <DialogFooter className="sm:justify-center">
              <Button type="submit" disabled={isLoading || otp.length < 6} className="w-full">
                {isLoading ? (
                    <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verifying...
                    </>
                ) : (
                    "Verify Account"
                )}
              </Button>
            </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
