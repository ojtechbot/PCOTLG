
"use client"

import React, { createContext, useContext, useCallback, ReactNode } from 'react';

type SoundType = 'notification' | 'preloader' | 'sendMessage';

interface SoundContextType {
  playSound: (sound: SoundType) => void;
}

const SoundContext = createContext<SoundContextType | undefined>(undefined);

const soundFiles: Record<SoundType, string> = {
  notification: 'https://cdn.pixabay.com/audio/2022/03/15/audio_2c6a8a313c.mp3', // Simple notification
  preloader: 'https://cdn.pixabay.com/audio/2022/11/17/audio_85d13f8953.mp3', // Success chime
  sendMessage: 'https://cdn.pixabay.com/audio/2021/08/04/audio_c6d1f3b2d1.mp3', // Pop sound
};

export const SoundProvider = ({ children }: { children: ReactNode }) => {

  const playSound = useCallback((sound: SoundType) => {
    // Ensure this only runs on the client
    if (typeof window !== 'undefined') {
      try {
        const audio = new Audio(soundFiles[sound]);
        audio.volume = 0.3; // Lowered volume slightly
        // The play() method returns a promise which can be safely ignored here
        // if it fails due to browser restrictions. The interaction listener in Preloader
        // should handle the preloader sound case.
        audio.play().catch(error => {
          // Log non-interrupt errors, which are common and usually benign
          if (error.name !== 'AbortError') {
            console.error(`Error playing sound '${sound}':`, error);
          }
        });
      } catch (e) {
          console.error("Failed to create or play audio:", e);
      }
    }
  }, []);

  return (
    <SoundContext.Provider value={{ playSound }}>
      {children}
    </SoundContext.Provider>
  );
};

export const useSound = (): SoundContextType => {
  const context = useContext(SoundContext);
  if (context === undefined) {
    throw new Error('useSound must be used within a SoundProvider');
  }
  return context;
};
