
'use server';

/**
 * @fileOverview AI flow to handle contact form submissions.
 *
 * - sendContactMessage - A function that processes the contact form data.
 * - ContactMessageInput - The input type for the sendContactMessage function.
 * - ContactMessageOutput - The return type for the sendContactMessage function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ContactMessageInputSchema = z.object({
  name: z.string().describe('The name of the person sending the message.'),
  email: z.string().email().describe('The email address of the sender.'),
  message: z.string().describe('The content of the message.'),
});
export type ContactMessageInput = z.infer<typeof ContactMessageInputSchema>;

const ContactMessageOutputSchema = z.object({
  success: z.boolean().describe('Whether the message was sent successfully.'),
  message: z.string().describe('A confirmation or error message.'),
});
export type ContactMessageOutput = z.infer<typeof ContactMessageOutputSchema>;

export async function sendContactMessage(
  input: ContactMessageInput
): Promise<ContactMessageOutput> {
  return sendContactMessageFlow(input);
}

// In a real application, you would use a service like Resend or SendGrid here
// and call their API with a secure API key stored in environment variables.
// For now, we will simulate a successful submission.
const sendContactMessageFlow = ai.defineFlow(
  {
    name: 'sendContactMessageFlow',
    inputSchema: ContactMessageInputSchema,
    outputSchema: ContactMessageOutputSchema,
  },
  async (input) => {
    console.log('Received contact form submission:', input);
    
    // TODO: Implement actual email sending logic here using a secure service.
    
    return {
      success: true,
      message: 'Thank you for your message! We will get back to you shortly.',
    };
  }
);
