
'use server';

/**
 * @fileOverview AI flow to verify a one-time password (OTP).
 *
 * - verifyOtp - A function that checks if an OTP is valid.
 * - VerifyOtpInput - The input type for the verifyOtp function.
 * - VerifyOtpOutput - The return type for the verifyOtp function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'zod';
import { doc, getDoc, updateDoc, Timestamp } from 'firebase/firestore';
import { db } from '@/lib/firebase';

// --- Input and Output Schemas ---

const VerifyOtpInputSchema = z.object({
  email: z.string().email().describe('The email address associated with the OTP.'),
  otp: z.string().length(6, "OTP must be 6 digits.").describe('The 6-digit one-time password.'),
});
export type VerifyOtpInput = z.infer<typeof VerifyOtpInputSchema>;

const VerifyOtpOutputSchema = z.object({
  success: z.boolean().describe('Whether the OTP was verified successfully.'),
  message: z.string().describe('A confirmation or error message.'),
});
export type VerifyOtpOutput = z.infer<typeof VerifyOtpOutputSchema>;

// --- Main exported function ---

export async function verifyOtp(input: VerifyOtpInput): Promise<VerifyOtpOutput> {
  return verifyOtpFlow(input);
}


// --- Genkit Flow Definition ---

const verifyOtpFlow = ai.defineFlow(
  {
    name: 'verifyOtpFlow',
    inputSchema: VerifyOtpInputSchema,
    outputSchema: VerifyOtpOutputSchema,
  },
  async ({ email, otp }) => {
    try {
        const otpDocRef = doc(db, 'otps', email);
        const otpDoc = await getDoc(otpDocRef);

        if (!otpDoc.exists()) {
            return { success: false, message: 'Invalid or expired OTP. Please try again.' };
        }

        const otpData = otpDoc.data();
        const now = Timestamp.now();
        
        // Ensure expires is a Firestore Timestamp object before comparison
        const expires = otpData.expires as Timestamp;
        if (!expires || typeof expires.toMillis !== 'function') {
             console.error("Invalid 'expires' field in OTP document:", otpData);
             return { success: false, message: 'Invalid OTP data format. Please try again.' };
        }


        if (otpData.verified) {
            return { success: false, message: 'This OTP has already been used.' };
        }

        if (expires.toMillis() < now.toMillis()) {
            return { success: false, message: 'Your OTP has expired. Please request a new one.' };
        }

        if (otpData.otp !== otp) {
            return { success: false, message: 'The OTP you entered is incorrect.' };
        }

        // OTP is valid. Mark it as verified to prevent reuse.
        await updateDoc(otpDocRef, { verified: true });
        
        return { success: true, message: 'Email verified successfully!' };

    } catch (dbError) {
        console.error('Error verifying OTP in Firestore:', dbError);
        return {
            success: false,
            message: 'An internal error occurred. Please try again later.',
        };
    }
  }
);
