
"use client"

import { DashboardLayout } from "@/components/dashboard-layout";
import PublicLayout from "@/app/(public)/layout";
import { HandDrawnSeparator } from "@/components/icons";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Mail, MapPin, Phone, Loader2 } from "lucide-react";
import { useState } from "react";
import { sendContactMessage } from "@/ai/flows/send-contact-message";
import { useAuth } from "@/hooks/use-auth";
import { Skeleton } from "@/components/ui/skeleton";


function ContactPageContent() {
    const { toast } = useToast();
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setIsLoading(true);
        const formData = new FormData(e.currentTarget);
        const name = formData.get("name") as string;
        const email = formData.get("email") as string;
        const message = formData.get("message") as string;

        try {
            const result = await sendContactMessage({ name, email, message });
            if (result.success) {
                toast({
                    title: "Message Sent!",
                    description: result.message,
                });
                e.currentTarget.reset();
            } else {
                 toast({
                    variant: "destructive",
                    title: "Submission Failed",
                    description: result.message,
                });
            }
        } catch (error) {
             toast({
                variant: "destructive",
                title: "An Error Occurred",
                description: "Could not send your message. Please try again later.",
            });
        } finally {
            setIsLoading(false);
        }
    }

    return (
         <div className="flex-1 space-y-8 p-4 md:p-8">
            <div className="flex flex-col items-center text-center space-y-2">
            <h1 className="text-4xl font-headline font-bold tracking-tight text-primary">
                Get In Touch
            </h1>
            <p className="text-muted-foreground max-w-2xl">
                We'd love to hear from you. Whether you have a question, a prayer request, or just want to say hello, please don't hesitate to reach out.
            </p>
            </div>

            <HandDrawnSeparator className="stroke-current text-border/50" />

            <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-12">
                <div className="space-y-8">
                    <Card>
                        <CardHeader>
                            <CardTitle className="font-headline">Contact Form</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <form onSubmit={handleSubmit} className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="name">Name</Label>
                                    <Input id="name" name="name" required />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="email">Email</Label>
                                    <Input id="email" name="email" type="email" required />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="message">Message</Label>
                                    <Textarea id="message" name="message" rows={5} required />
                                </div>
                                <Button type="submit" className="w-full" disabled={isLoading}>
                                    {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                    {isLoading ? "Sending..." : "Send Message"}
                                </Button>
                            </form>
                        </CardContent>
                    </Card>
                </div>
                <div className="space-y-8">
                    <Card>
                        <CardHeader>
                            <CardTitle className="font-headline">Our Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4 text-muted-foreground">
                            <div className="flex items-start gap-4">
                                <MapPin className="w-6 h-6 text-primary mt-1" />
                                <div>
                                    <h3 className="font-semibold text-foreground">Our Address</h3>
                                    <p>7409 Hancock Towns Ct, Chesterfield VA 23832</p>
                                </div>
                            </div>
                            <div className="flex items-start gap-4">
                                <Phone className="w-6 h-6 text-primary mt-1" />
                                <div>
                                    <h3 className="font-semibold text-foreground">Phone</h3>
                                    <p>+1 (246) 267-4110</p>
                                </div>
                            </div>
                            <div className="flex items-start gap-4">
                                <Mail className="w-6 h-6 text-primary mt-1" />
                                <div>
                                    <h3 className="font-semibold text-foreground">Email</h3>
                                    <p>info@pcotlg.org</p>
                                    <p>bishopjtosh@gmail.com</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle className="font-headline">Service Times</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2 text-muted-foreground">
                            <div className="flex justify-between">
                                <span>Sunday Morning</span>
                                <span className="font-semibold text-foreground">10:00 AM</span>
                            </div>
                            <div className="flex justify-between">
                                <span>Wednesday Bible Study</span>
                                <span className="font-semibold text-foreground">7:00 PM</span>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle className="font-headline">Our Location</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="aspect-video w-full">
                                <iframe
                                    src="https://maps.google.com/maps?q=7409%20Hancock%20Towns%20Ct%2C%20Chesterfield%20VA%2023832&t=&z=15&ie=UTF8&iwloc=&output=embed"
                                    width="100%"
                                    height="100%"
                                    style={{ border: 0 }}
                                    allowFullScreen={true}
                                    loading="lazy"
                                    referrerPolicy="no-referrer-when-downgrade"
                                ></iframe>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    )
}

export default function ContactPage() {
    const { user, loading } = useAuth();

    if (loading) {
        return (
            <DashboardLayout>
                <div className="p-8 space-y-4">
                    <Skeleton className="h-12 w-1/2 mx-auto" />
                    <Skeleton className="h-6 w-3/4 mx-auto" />
                    <Skeleton className="h-96 w-full max-w-5xl mx-auto mt-8" />
                </div>
            </DashboardLayout>
        )
    }

    if (user) {
        return (
            <DashboardLayout>
                <ContactPageContent />
            </DashboardLayout>
        )
    }

    return (
        <PublicLayout>
            <ContactPageContent />
        </PublicLayout>
    )
}
