
"use client"

import { DashboardLayout } from "@/components/dashboard-layout";
import PublicLayout from "@/app/(public)/layout";
import { HandDrawnSeparator } from "@/components/icons";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Users, BookOpen, Heart, Rocket, Target, Church } from "lucide-react";
import Image from "next/image";
import { useAuth } from "@/hooks/use-auth";
import { Skeleton } from "@/components/ui/skeleton";

const beliefs = [
  {
    title: "The Holy Bible",
    content: "We believe in the Holy Bible as the divinely inspired, infallible, inerrant, irrevocable, authoritative Word of God and of such, it is the final arbitrator in all matters of faith and practice. (2 Tim. 3:16; 1 Cor. 2:13)."
  },
  {
    title: "The Nature of God",
    content: "We believe in the Eternal Fatherhood of God, who has revealed Himself as one God existing in three persons, Father, Son and Holy Spirit, distinguishable but indivisible (Mat. 28:19; 2 Cor. 13:14)."
  },
  {
    title: "Sanctity of Human Life",
    content: "We believe in the sanctity of human life, the dignity and worth of the human person and the unconditional equality of all men everywhere regardless of race, place of origin, political opinion, colour, creed or sex. As such all men must be free from discrimination."
  },
  {
    title: "The Person of Christ Jesus",
    content: "We believe in the historicity of the Man, Christ Jesus, His pre-incarnate existence as one with the Father, His virgin birth, sinless humanity and unqualified Deity, his atoning death; burial; resurrection, ascension to the Father's Right hand and soon coming again as the Eternal Son of God, the Father and only Redeemer of mankind."
  },
  {
    title: "Sacred Christian Rites and Marriage",
    content: "We believe in and practice such sacred Christian rites as – Fundamentals of marriage; (which has only one meaning: the uniting of one man and one woman in a single, exclusive union, as delineated in Scripture (Gen. 2:18-25)); Baptism by immersion, The Lord's Supper/The Holy Communion, Tithing, Ordination of Ministers, Burial of the Christian Dead, Church Gatherings, Ministry, and Gifts of the Holy Spirit. We believe that God, wonderfully and immutably, creates each person as male and female. These two distinct, complementary genders together reflect the image of God. (Gen. 1:26-27). Rejection of one’s biological sex is a rejection of the image of God within that person."
  },
  {
    title: "Core Christian Doctrines",
    content: "We believe in the Christian doctrines of Sin, Salvation, Grace, Faith, Repentance, Regeneration, Reconciliation and Sanctification."
  },
  {
    title: "The Church (Ecclesia)",
    content: "We believe that the church 'Ecclesia' is a 'called out' body, both a living organism and organization, local and universal made up of individuals or community of believers everywhere welded together by the Spirit through Jesus Christ."
  },
  {
    title: "Eternal State",
    content: "We believe in the eternal blessedness of the redeemed in heaven (Jn. 5:24; 3:16) and the eternal damnation of the unregenerate, in the lake of fire (Hell). (Mk. 9:43-48; 2 Thes. 1:9; Rev. 20:10-15)."
  },
  {
    title: "Eschatology (End Times)",
    content: "We believe in the eschatological doctrine of the New Testament Church, which embraces the Rapture; Tribulation; the Personal Second Coming of Christ; Judgments of all People and Nations; the reward of Saints; the retribution of the Sinner; the Great White Throne Judgment; the Millennium, and the Reality of Heaven and Hell."
  },
  {
    title: "Gifts of the Holy Spirit",
    content: "We believe in the Baptism of the Holy Spirit, with the evidence of speaking in other tongues, in addition to the other ministry gifts of the Holy Spirit, including the offices of the Apostle, Prophet, Teacher, Pastor, Evangelist, among others as outlined in the New Testament. (Acts 2:4; Eph. 4:11-12)."
  }
];

const coreValues = [
    {
        icon: Users,
        title: "Community",
        description: "We are a family, committed to supporting and encouraging one another through all of life's joys and challenges."
    },
    {
        icon: BookOpen,
        title: "Biblical Truth",
        description: "We believe the Bible is the inspired Word of God and the ultimate authority for our faith and lives."
    },
    {
        icon: Heart,
        title: "Compassionate Service",
        description: "We are called to be the hands and feet of Jesus, serving our local and global communities with love."
    }
]

function AboutPageContent() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative bg-secondary/30 py-20 md:py-32">
        <div className="absolute inset-0">
          <Image src="/images/gallery-4.jpg" alt="Church building" fill className="object-cover opacity-10" data-ai-hint="church building" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent"></div>
        </div>
        <div className="container mx-auto px-4 relative text-center">
            <Church className="w-16 h-16 mx-auto text-primary mb-4" />
            <h1 className="text-4xl md:text-5xl font-headline font-bold text-primary">
                About The Pentecostal Church of the Living God
            </h1>
            <p className="mt-4 text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
                Learn more about our history, our mission, and what we believe as a community of faith dedicated to serving God and our neighbors.
            </p>
        </div>
      </section>

    <div className="flex-1 space-y-16 p-4 md:p-8">
      <div className="container mx-auto max-w-5xl space-y-16">
          {/* Mission and Vision Section */}
          <section className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
              <div className="space-y-4">
                  <Rocket className="w-10 h-10 text-primary" />
                  <h2 className="text-3xl md:text-4xl font-headline text-primary">Our Mission</h2>
                  <p className="text-base md:text-lg text-muted-foreground">
                  To present a clear and faithful interpretation of Scripture that inspires discovery, understanding, and application of God’s Word, cultivating Christlike maturity in believers.
                  </p>
                  <p className="text-base md:text-lg text-muted-foreground">
                  Through prophetic and healing anointing's, we aim to grow vibrant church communities, prepare believers for ministry and global missions, and impact lives through teaching, discipleship, and acts of service.
                  </p>
              </div>
              <div className="space-y-4">
                   <Target className="w-10 h-10 text-primary" />
                    <h2 className="text-3xl md:text-4xl font-headline text-primary">Our Vision</h2>
                    <p className="text-base md:text-lg text-muted-foreground">
                    To transform lives through the unadulterated Word of God, fostering spiritual growth, healing, and empowerment while equipping believers to fulfill their divine purpose and magnify God’s name globally.
                    </p>
              </div>
          </section>

           <HandDrawnSeparator className="stroke-current text-border/50" />

           {/* Welcome Message Section */}
            <section className="grid lg:grid-cols-5 gap-x-12 gap-y-8 items-center">
                <div className="lg:col-span-2">
                    <Image 
                        src="/images/bishop.png" 
                        alt="Bishop Justin M. McIntosh"
                        width={600} 
                        height={700}
                        className="rounded-lg shadow-xl"
                        data-ai-hint="portrait bishop" 
                    />
                </div>
                 <div className="lg:col-span-3">
                    <h2 className="text-3xl md:text-4xl font-headline text-primary mb-4">A Message From Our Bishop</h2>
                    <div className="space-y-4 text-base md:text-lg text-muted-foreground">
                        <p>
                            God has raised up Justin Martin McIntosh as a pioneer for His people. He has played an instrumental role in planting several churches in Barbados. Currently, Bishop McIntosh serves as the presiding Bishop of three Pentecostal Church of the Living God congregations and is involved in the organization and structuring of other local churches.
                        </p>
                        <p>
                            Our Purpose Statement is taken from the acronym TIME: To grow in our membership, Into Christlike maturity, Making ready for ministry in the church and mission in the world, Effectively affecting lives to magnify God’s name.
                        </p>
                        <p className="font-semibold text-foreground">
                            We invite you to explore our app and reap the benefits thereof, and also learn how you can partner with us in making a difference in this generation. God bless you abundantly.
                        </p>
                    </div>
                </div>
            </section>

            <HandDrawnSeparator className="stroke-current text-border/50" />

            {/* Core Values */}
            <section>
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-headline text-primary">Our Core Values</h2>
                    <p className="mt-2 text-muted-foreground text-base md:text-lg">What we stand for as a community.</p>
                </div>
                <div className="grid md:grid-cols-3 gap-8">
                    {coreValues.map(value => (
                        <div key={value.title} className="text-center p-6">
                             <div className="flex justify-center mb-4">
                                <div className="p-4 bg-primary/10 rounded-full">
                                    <value.icon className="w-8 h-8 text-primary" />
                                </div>
                            </div>
                            <h3 className="font-headline text-2xl text-foreground mb-2">{value.title}</h3>
                            <p className="text-muted-foreground text-base">{value.description}</p>
                        </div>
                    ))}
                </div>
            </section>
            
            <HandDrawnSeparator className="stroke-current text-border/50" />

          {/* Statement of Faith */}
          <section>
            <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-headline text-primary">What We Believe</h2>
                <p className="text-muted-foreground mt-2 text-base md:text-lg">Our statement of faith.</p>
            </div>
            <Accordion type="single" collapsible className="w-full">
                {beliefs.map((belief, index) => (
                    <AccordionItem value={`item-${index + 1}`} key={index}>
                        <AccordionTrigger className="text-lg md:text-xl font-headline hover:no-underline text-left">
                           {index + 1}. {belief.title}
                        </AccordionTrigger>
                        <AccordionContent className="text-base md:text-lg text-muted-foreground pl-2 pr-6">
                            {belief.content}
                        </AccordionContent>
                    </AccordionItem>
                ))}
            </Accordion>
          </section>
      </div>
    </div>
    </>
  )
}


export default function AboutPage() {
    const { user, loading } = useAuth();

    if (loading) {
        return (
            <DashboardLayout>
                <div className="p-8 space-y-4">
                    <Skeleton className="h-48 w-full" />
                    <Skeleton className="h-12 w-1/2 mx-auto mt-8" />
                    <Skeleton className="h-6 w-3/4 mx-auto" />
                    <Skeleton className="h-96 w-full mt-8" />
                </div>
            </DashboardLayout>
        )
    }

    if (user) {
        return (
            <DashboardLayout>
                <AboutPageContent />
            </DashboardLayout>
        )
    }

    return (
        <PublicLayout>
            <AboutPageContent />
        </PublicLayout>
    )
}
