
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Mail, Lock, User, Eye, EyeOff, Loader2 } from "lucide-react";
import { ForgotPasswordDialog } from "@/components/forgot-password-dialog";
import { OtpVerificationDialog } from "@/components/otp-verification-dialog";
import { useToast } from "@/hooks/use-toast";
import { auth, db } from "@/lib/firebase";
import { createUserWithEmailAndPassword, fetchSignInMethodsForEmail, signInWithEmailAndPassword, updateProfile } from "firebase/auth";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { createUserDocument, updateUserLastLogin } from "@/lib/database/users";
import { sendOtp } from "@/ai/flows/send-otp";
import { sendWelcomeEmail } from "@/ai/flows/send-welcome-email";
import { createNotification } from "@/lib/database/notifications";
import { doc, getDoc } from "firebase/firestore";

export default function AuthPage() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);
  const [isOtpDialogOpen, setIsOtpDialogOpen] = useState(false);

  // State to hold signup data while OTP is being verified
  const [signupData, setSignupData] = useState({ name: "", email: "", password: "" });

  const { toast } = useToast();
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const formData = new FormData(e.currentTarget);
    const email = formData.get("email-login") as string;
    const password = formData.get("password-login") as string;

    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        // Ensure user document exists, create if it doesn't
        const userDocRef = doc(db, "users", user.uid);
        const userDoc = await getDoc(userDocRef);
        if (!userDoc.exists()) {
            await createUserDocument(user);
        }
        
        await updateUserLastLogin(user.uid);

        // Send login notification
        await createNotification({
            userId: user.uid,
            title: "Security Alert: New Login",
            body: "We detected a new login to your account. If this was not you, please secure your account immediately.",
            link: "/settings"
        });

        router.push('/success');
    } catch (error: any) {
        toast({
            variant: "destructive",
            title: "Login Failed",
            description: error.message || "Invalid credentials. Please try again.",
        });
    } finally {
        setIsSubmitting(false);
    }
  }

  const handleSignup = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const formData = new FormData(e.currentTarget);
    const name = formData.get("name-signup") as string;
    const email = formData.get("email-signup") as string;
    const password = formData.get("password-signup") as string;

    // Check if user already exists
    try {
      const signInMethods = await fetchSignInMethodsForEmail(auth, email);
      if (signInMethods.length > 0) {
        toast({
          variant: "destructive",
          title: "User Already Exists",
          description: "This email address is already registered. Please log in.",
        });
        setIsSubmitting(false);
        return;
      }
    } catch (error) {
      console.error("Error checking for existing user:", error);
      // We can proceed, as this might be a network issue, and the OTP send will handle it.
    }


    // Store signup data in state
    setSignupData({ name, email, password });

    try {
        const result = await sendOtp({ name, email });
        if (result.success) {
            toast({
                title: "OTP Sent!",
                description: result.message,
            });
            setIsOtpDialogOpen(true);
        } else {
             toast({
                variant: "destructive",
                title: "OTP Failed",
                description: result.message,
            });
        }
    } catch (error) {
        toast({
            variant: "destructive",
            title: "Sign-up Failed",
            description: "An unexpected error occurred while sending the OTP.",
        });
    } finally {
        setIsSubmitting(false);
    }
  }
  
  const handleOtpVerified = async () => {
    // This function is called from the OTP dialog on successful verification
    setIsOtpDialogOpen(false);
    setIsSubmitting(true);
    try {
        const userCredential = await createUserWithEmailAndPassword(auth, signupData.email, signupData.password);
        const user = userCredential.user;
        
        await updateProfile(user, { displayName: signupData.name });
        await createUserDocument(user);
        
        // Send welcome email after account is created
        await sendWelcomeEmail({ name: signupData.name, email: signupData.email });

        router.push('/success');
    } catch (error: any) {
        toast({
            variant: "destructive",
            title: "Account Creation Failed",
            description: error.message,
        });
    } finally {
        setIsSubmitting(false);
    }
  }


  return (
    <>
    <div className="w-full lg:grid lg:min-h-screen lg:grid-cols-2 xl:min-h-screen">
      <div className="flex items-center justify-center p-6 py-12 lg:p-10">
        <div className="mx-auto grid w-[350px] gap-6">
           <div className="grid gap-2 text-center">
             <Link href="/home" className="inline-block justify-center items-center">
                <Image src="/images/logo.png" alt="PCOTLG Logo" width={64} height={64} className="mx-auto mb-4" />
             </Link>
            <h1 className="text-3xl font-bold font-headline text-primary">Welcome to PCOTLG</h1>
            <p className="text-balance text-muted-foreground">
              Sign in or create an account to join our community.
            </p>
          </div>
           <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="signup">Sign Up</TabsTrigger>
            </TabsList>
            <TabsContent value="login">
                <Card className="border-0 shadow-none">
                    <CardHeader className="p-0 pt-6">
                        <CardDescription>
                        Welcome back! Please enter your details.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="p-0 pt-4">
                        <form onSubmit={handleLogin} className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="email-login">Email</Label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                    <Input id="email-login" name="email-login" type="email" placeholder="User@email.com" required className="pl-10" />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="password-login">Password</Label>
                                <div className="relative">
                                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                    <Input id="password-login" name="password-login" placeholder="Enter password" type={showLoginPassword ? 'text' : 'password'} required className="pl-10 pr-10" />
                                    <button type="button" onClick={() => setShowLoginPassword(!showLoginPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground">
                                        {showLoginPassword ? <EyeOff /> : <Eye />}
                                    </button>
                                </div>
                            </div>
                            <Button type="submit" className="w-full" disabled={isSubmitting}>
                            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : null}
                            {isSubmitting ? 'Signing in...' : 'Login'}
                            </Button>
                        </form>
                        <div className="mt-4 text-center text-sm">
                        <button onClick={() => setIsForgotPasswordOpen(true)} className="underline text-muted-foreground">
                            Forgot your password?
                        </button>
                        </div>
                    </CardContent>
                </Card>
            </TabsContent>
            <TabsContent value="signup">
                <Card className="border-0 shadow-none">
                    <CardHeader className="p-0 pt-6">
                        <CardDescription>
                        Create an account to join the community. We'll send you a code to verify your email.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="p-0 pt-4">
                        <form onSubmit={handleSignup} className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="name-signup">Name</Label>
                                <div className="relative">
                                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                    <Input id="name-signup" name="name-signup" placeholder="Enter full name" required className="pl-10" />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="email-signup">Email</Label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                    <Input id="email-signup" name="email-signup" type="email" placeholder="User@email.com" required className="pl-10"/>
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="password-signup">Password</Label>
                                <div className="relative">
                                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                    <Input id="password-signup" name="password-signup" placeholder="Create password (min. 6 characters)" type={showSignupPassword ? 'text' : 'password'} required className="pl-10 pr-10"/>
                                    <button type="button" onClick={() => setShowSignupPassword(!showSignupPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground">
                                        {showSignupPassword ? <EyeOff /> : <Eye />}
                                    </button>
                                </div>
                            </div>
                            <Button type="submit" className="w-full" disabled={isSubmitting}>
                            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : null}
                            {isSubmitting ? 'Sending Code...' : 'Get Verification Code'}
                            </Button>
                        </form>
                    </CardContent>
                </Card>
            </TabsContent>
            </Tabs>
        </div>
      </div>
      <div className="hidden bg-muted lg:block">
        <Image
          src="/images/logo.png"
          alt="Image"
          width="1920"
          height="1080"
          className="h-full w-full object-cover dark:brightness-[0.3] dark:grayscale"
          data-ai-hint="church congregation"
        />
      </div>
    </div>
    {isForgotPasswordOpen && <ForgotPasswordDialog onOpenChange={setIsForgotPasswordOpen} />}
    {isOtpDialogOpen && (
        <OtpVerificationDialog 
            email={signupData.email}
            onOpenChange={setIsOtpDialogOpen}
            onVerified={handleOtpVerified}
        />
    )}
    </>
  );
}
