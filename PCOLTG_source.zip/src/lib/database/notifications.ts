
import {
  collection,
  doc,
  addDoc,
  deleteDoc,
  serverTimestamp,
  writeBatch,
  query,
  where,
  getDocs,
} from 'firebase/firestore';
import { db } from '../firebase';
import { sendNotificationToUser } from '../server-actions/notifications';


export interface NotificationData {
    title: string;
    body: string;
    link?: string;
    userId?: string | null; // Optional: To target a specific user
}


export const createNotification = async (data: NotificationData) => {
    const notificationsRef = collection(db, 'notifications');
    try {
        // Create in-app notification
        const docData: any = {
            ...data,
            read: false,
            createdAt: serverTimestamp(),
        };

        if (data.userId) {
            docData.userId = data.userId;
        } else {
            docData.userId = null; // Explicitly set for global notifications
        }

        await addDoc(notificationsRef, docData);

        // This function now calls a server action to handle push/email
        // We will no longer call this from here to avoid duplicate sends.
        // The responsibility is moved to the flows that initiate notifications.
        // await sendNotificationToUser(data);

    } catch (error) {
        console.error("Error creating notification record:", error);
        throw error; // Re-throw to be handled by the caller
    }
};

export const deleteNotification = async (notificationId: string) => {
    const notificationRef = doc(db, 'notifications', notificationId);
    await deleteDoc(notificationRef);
};

export const deleteAllNotificationsForUser = async (userId: string) => {
    const q = query(collection(db, 'notifications'), where('userId', '==', userId));
    const snapshot = await getDocs(q);
    const batch = writeBatch(db);
    snapshot.docs.forEach(doc => {
        batch.delete(doc.ref);
    });
    await batch.commit();
}
