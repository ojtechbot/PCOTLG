
import {
  doc,
  updateDoc,
  serverTimestamp,
  getDoc,
  setDoc,
  Timestamp,
  deleteDoc,
} from 'firebase/firestore';
import { db, auth, storage } from '../firebase';
import { updateProfile, type User as FirebaseUser } from 'firebase/auth';
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { createNotification } from './notifications';
import { deleteUser as deleteUserAdmin, updateUser, updatePassword } from '../server-actions/users';


// User Profile Management
export const createUserDocument = async (user: FirebaseUser) => {
    const userDocRef = doc(db, "users", user.uid);
    const userDoc = await getDoc(userDocRef);

    // Only create the document if it doesn't already exist.
    if (!userDoc.exists()) {
        const { displayName, email, photoURL } = user;
        const createdAt = new Date();
        
        await setDoc(userDocRef, {
            name: displayName,
            email,
            photoURL,
            createdAt: Timestamp.fromDate(createdAt),
            lastLogin: Timestamp.fromDate(createdAt),
            role: 'user', // All new signups are users by default
            fcmTokens: [], // Initialize fcmTokens array
            bio: "",
            dob: null,
            country: "",
            phone: "",
            state: "",
            zip: "",
        });
    }
};

export const updateUserLastLogin = async (uid: string) => {
    const userDocRef = doc(db, "users", uid);
    await updateDoc(userDocRef, {
        lastLogin: serverTimestamp()
    });
};


export const updateUserDocumentAndPhoto = async (data: { 
    name: string; 
    photoFile: File | null;
    bio?: string;
    dob?: string;
    country?: string;
    phone?: string;
    state?: string;
    zip?: string;
}) => {
    const user = auth.currentUser;
    if (!user) throw new Error("User not authenticated to update profile.");

    let photoURL = user.photoURL;

    // If a new photo is provided, upload it and get the URL
    if (data.photoFile) {
        const storageRef = ref(storage, `profilePictures/${user.uid}`);
        const snapshot = await uploadBytes(storageRef, data.photoFile);
        photoURL = await getDownloadURL(snapshot.ref);
    }
    
    // Update the user's profile in Firebase Auth
    await updateProfile(user, {
      displayName: data.name,
      photoURL: photoURL
    });

    // Construct the data object for Firestore, carefully removing undefined values
    const firestoreData: { [key: string]: any } = {
        name: data.name,
        photoURL: photoURL,
        updatedAt: serverTimestamp()
    };

    // Only add fields to the update object if they are defined
    if (data.bio !== undefined) firestoreData.bio = data.bio;
    if (data.dob) firestoreData.dob = data.dob;
    if (data.country !== undefined) firestoreData.country = data.country;
    if (data.phone !== undefined) firestoreData.phone = data.phone;
    if (data.state !== undefined) firestoreData.state = data.state;
    if (data.zip !== undefined) firestoreData.zip = data.zip;

    // Update the user document in Firestore
    const userDocRef = doc(db, "users", user.uid);
    await updateDoc(userDocRef, firestoreData);
    
    // Create a notification for the current user confirming their profile update
    await createNotification({
        title: "Profile Updated",
        body: "Your profile information has been successfully saved.",
        link: "/settings",
        userId: user.uid, // Target this notification to the current user
    });
};

// Admin Functions (calling server actions)
export const updateUserDocumentAdmin = async (uid: string, data: { name: string; email: string; role: 'admin' | 'user' }) => {
    await updateUser(uid, data);
}

export const updateUserPasswordAdmin = async (uid: string, password: string) => {
    await updatePassword(uid, password);
}

export const deleteUser = async (uid: string) => {
    // This is a client-side function that will call the server action
    // to perform the deletion with admin privileges.
    await deleteUserAdmin(uid);
    // Also delete the user's document from Firestore
    await deleteDoc(doc(db, "users", uid));
};
